# Guía de la Fase 4: pantalla inicial, registro/login y catálogo

Todo desde la raíz del repo, en su Codespace.

## Paso 1: Copiar los archivos
```bash
unzip -o fase4-catalogo.zip
git status --short
```
Deben aparecer como **modificados**: `docker-compose.yml`, `docker/postgres/init.sql`, `backend/gateway/krakend/{generate.py,krakend.json,krakend.local.json}`, `backend/microservicios/auth/{service.py,router.py,tests/...}`, `frontend-react/src/{App.jsx,main.jsx,styles.css,utils.js,api/http.js,pages/Home.jsx,pages/Login.jsx}`; y como **nuevos**: `backend/microservicios/emprendimientos/`, `frontend-react/src/{auth,api/auth.js,api/ventures.js,components/Guards.jsx,components/venture.jsx,pages/...}`.

## Paso 2: Crear la base de datos `emprendimientos`
```bash
docker compose up -d db
docker compose exec db psql -U postgres -c "CREATE DATABASE emprendimientos;"
```
(`already exists` está bien.)

## Paso 3: Validar el gateway
```bash
docker run --rm -v "$PWD/backend/gateway/krakend/krakend.json:/etc/krakend/krakend.json:ro" krakend:latest check -c /etc/krakend/krakend.json
```
Debe decir `Syntax OK!`. Si falla, péguenme el mensaje completo.

## Paso 4: Levantar todo
```bash
docker compose up --build -d
docker compose ps
```
Esperen a que todo esté `healthy` (el frontend tarda más porque se recompila). Si algo falla: `docker compose logs emprendimientos` (o `auth`, `gateway`, `frontend`).

## Paso 5: Pruebas automáticas
```bash
docker compose run --rm --no-deps -v "$PWD/backend/microservicios/auth/tests:/app/tests:ro" auth \
  sh -c "pip install --user -q pytest==8.3.4 httpx==0.28.1 && python -m pytest tests -q"

docker compose run --rm --no-deps -v "$PWD/backend/microservicios/emprendimientos/tests:/app/tests:ro" emprendimientos \
  sh -c "pip install --user -q pytest==8.3.4 httpx==0.28.1 && python -m pytest tests -q"
```
Esperado: auth ≈ **70 pruebas** en verde y emprendimientos **29**.

## Paso 6: Prueba del gateway con curl (seguridad)
```bash
G=http://localhost:8080/api/v1
# Dos emprendedores
A=$(curl -s $G/auth/register -H 'Content-Type: application/json' -d '{"email":"a@test.co","password":"Clave12345","name":"Ana","role":"entrepreneur"}' | jq -r .access_token)
B=$(curl -s $G/auth/register -H 'Content-Type: application/json' -d '{"email":"b@test.co","password":"Clave12345","name":"Beto","role":"entrepreneur"}' | jq -r .access_token)
V=$(curl -s $G/auth/register -H 'Content-Type: application/json' -d '{"email":"v@test.co","password":"Clave12345","name":"Vera","role":"visitor"}' | jq -r .access_token)

curl -s -X PUT $G/me/venture -H "Authorization: Bearer $A" -H 'Content-Type: application/json' -d '{"name":"Negocio de Ana","description":"Hecho a mano"}' | jq .name
curl -s -X PUT $G/me/venture -H "Authorization: Bearer $B" -H 'Content-Type: application/json' -d '{"name":"Negocio de Beto","description":"Cafe"}' | jq .name
```
Comprobaciones (cada una con el resultado esperado):
```bash
# 1. Sin token -> 401
curl -s -o /dev/null -w "%{http_code}\n" $G/me/venture
# 2. Visitante intentando entrar a rutas de emprendedor -> 403
curl -s -o /dev/null -w "%{http_code}\n" $G/me/venture -H "Authorization: Bearer $V"
# 3. X-User-Id falsificado: con el token de Ana pero diciendo ser otra cuenta -> debe responder "Negocio de Ana"
curl -s $G/me/venture -H "Authorization: Bearer $A" -H 'X-User-Id: 2' | jq .name
# 4. X-User-Id falsificado SIN token -> 401
curl -s -o /dev/null -w "%{http_code}\n" $G/me/venture -H 'X-User-Id: 1'
# 5. Borrador: aun no es publico -> 404
curl -s -o /dev/null -w "%{http_code}\n" $G/ventures/1
# 6. Publicar y verlo en el catalogo (sin token)
curl -s -X POST $G/me/venture/publish -H "Authorization: Bearer $A" | jq .is_published
curl -s "$G/ventures?q=ana" | jq '.total, .items[0].name'
# 7. El perfil publico NO expone el id de la cuenta -> false
curl -s $G/ventures/1 | jq 'has("owner_account_id")'
# 8. Favoritos del visitante
curl -s -o /dev/null -w "%{http_code}\n" -X PUT $G/me/favorites/1 -H "Authorization: Bearer $V"
curl -s $G/me/favorite-ids -H "Authorization: Bearer $V"
```
Esperado: `401`, `403`, `"Negocio de Ana"`, `401`, `404`, `true`, `1 / "Negocio de Ana"`, `false`, `204` y `{"ids":[1]}`.

**Si la comprobación 3 devuelve "Negocio de Beto"**, el gateway deja pasar el encabezado del cliente: avísenme antes de seguir, porque hay que corregirlo.

## Paso 7: Prueba en el navegador (puerto 8000)
1. `/` muestra los dos caminos. «Crear mi cuenta de emprendedor» abre el registro con el rol emprendedor marcado.
2. Registren un emprendedor → llega a **Mi panel**. Creen el emprendimiento: nace como **Borrador**. Intenten publicar sin descripción (debe avisar), completen y publiquen.
3. Vinculen Instagram con un enlace de otro sitio (debe rechazarlo) y luego con uno válido y seguidores (se ve «declarado por el emprendedor»).
4. Cierren sesión y abran `/explorar`: debe aparecer la tarjeta. Prueben búsqueda y categoría.
5. Sin sesión, pulsen **Guardar**: los lleva a ingresar y, al registrarse como visitante, vuelven al catálogo. Guardan y revisan `/favoritos`.
6. Recarguen la página: la sesión sigue (se recupera sola).
7. Como visitante entren a `/panel`: ofrece **activar rol de emprendedor** (misma cuenta).
8. Desde el celular (o el modo móvil del navegador) revisen que no haya desplazamiento horizontal.
9. «¿Olvidaste tu contraseña?»: con `MAIL_MODE=log` el enlace aparece en `docker compose logs auth`; ábranlo y cambien la clave.
10. Los botones de Google/Facebook **solo aparecen** cuando configuren sus credenciales en `backend/microservicios/auth/.env`.

## Qué me envían si algo falla
La salida completa del paso que falló (y `docker compose logs <servicio> --tail 50`).
