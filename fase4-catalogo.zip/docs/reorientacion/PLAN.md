# Reorientación: plataforma de emprendedores y visitantes

Documento vivo. Cubre la **Fase 1 (análisis)**, la **Fase 2 (plan)** y lo entregado en la **Fase 3**.
Rama de partida: `Kubernetes` (incluye React y los manifiestos de K8s).

## 1. Fase 1 — Lo que existe hoy

| Capa | Estado actual |
|---|---|
| Frontend | React 18 + Vite + React Router, servido por nginx (`frontend-react/`). 4 páginas CRUD genéricas (`CrudPage` + `config/resources.js`), `Home` con tarjetas, `Login` con botones **deshabilitados** (marcador). Cliente HTTP en `src/api/` contra `/api/v1`. |
| Gateway | KrakenD, config **generada** por `backend/gateway/krakend/generate.py` (29 endpoints, sin autenticación). nginx envía `/api/` al gateway (mismo origen, sin CORS). |
| Microservicios | FastAPI + SQLModel, capas `models / repository / service / router`, borrado lógico (`is_active`), `/restore` y tabla `*_audit`. `usuarios` (8002), `metodologias` (8003), `beneficios` (8001), `analisis` (8004). |
| Datos | Postgres, **una BD por servicio**. Referencias entre servicios por id, sin llaves foráneas. Tablas creadas con `create_all` (no hay migraciones). |
| Imágenes | `usuarios/storage.py`: contrato `ImageStorage` + `SupabaseStorage` (bucket público). Validación de tipo y 5 MB en `service.py`. |
| Seguridad | **No había** cuentas, roles ni tokens: cualquiera puede llamar a cualquier endpoint. |
| Despliegue | Docker Compose (un comando) y manifiestos K8s solo para `beneficios` y `analisis`. |

**Funcionalidades que se conservan sin cambios:** los 4 CRUD con borrado lógico, restauración y auditoría; la subida de imagen; el gateway; Compose; K8s.

## 2. Fase 2 — Decisiones de arquitectura

| # | Decisión | Por qué |
|---|---|---|
| D1 | **Microservicio nuevo `auth`** (puerto 8005, BD `auth`) | Aísla credenciales y sesiones; respeta "una BD por servicio" y SRP. Es el microservicio de login ya planeado. |
| D2 | **JWT RS256 validado en el gateway**; llave pública en `/.well-known/jwks.json` | KrakenD valida sin llamar a `auth` ni compartir secretos. Cada micro solo recibe el id de cuenta ya validado. |
| D3 | **Access token 15 min en memoria + refresh token 7 días en cookie httpOnly**, rotativo | Un XSS no puede leer la cookie; el robo de un refresh se detecta por reuso. |
| D4 | Contraseñas con **scrypt** (stdlib) | Sin dependencias nuevas con binarios; recomendado por OWASP. |
| D5 | Un servicio nuevo **`emprendimientos`** (Fase 4) con catálogo, categorías, redes, estadísticas y favoritos | El dominio nuevo no cabe en los 4 existentes y evita mezclar responsabilidades. |
| D6 | Los 4 módulos actuales **se conservan** como "Herramientas" del panel del emprendedor | Decisión del equipo: no romper lo que funciona. Se les agrega control de acceso en la Fase 5. |
| D7 | Imágenes: **seguir con Supabase Storage** (`ImageStorage`) | Ya existe, cumple "no guardar imágenes pesadas en Postgres" y el patrón permite cambiar de proveedor sin tocar la lógica. |
| D8 | Roles `visitor` y `entrepreneur`, **varios por cuenta** (tabla `account_roles`) | Una cuenta puede empezar con un rol y habilitar el otro sin crear otra. |
| D9 | Autenticación y vinculación de redes del negocio son **independientes** | Google/Facebook solo identifican a la persona (`oauth_identities`); Instagram, TikTok, etc. se vinculan al emprendimiento (Fase 5/6). |

### Modelo de datos objetivo

```mermaid
erDiagram
    ACCOUNTS ||--o{ ACCOUNT_ROLES : tiene
    ACCOUNTS ||--o{ OAUTH_IDENTITIES : "inicia sesion con"
    ACCOUNTS ||--o{ REFRESH_TOKENS : sesiones
    ACCOUNTS ||--o{ PASSWORD_RESET_TOKENS : recupera
    ACCOUNTS ||--o{ ACCOUNT_AUDIT : auditoria

    CATEGORIES ||--o{ VENTURES : clasifica
    VENTURES ||--o{ SOCIAL_LINKS : "una por plataforma"
    SOCIAL_LINKS ||--o{ FOLLOWER_STATS : historial
    SOCIAL_LINKS ||--o| SOCIAL_INTEGRATIONS : "datos de API"
    VENTURES ||--o{ FAVORITES : guardado_en
    VENTURES ||--o{ VENTURE_AUDIT : auditoria

    ACCOUNTS {
        int id PK
        string email UK
        string password_hash "nulo si solo usa Google/Facebook"
        string name
        bool is_active
    }
    ACCOUNT_ROLES {
        int account_id PK
        string role PK "visitor | entrepreneur"
    }
    VENTURES {
        int id PK
        int owner_account_id "ref. logica a auth (sin FK)"
        string name
        string entrepreneur_name
        bool show_entrepreneur_name
        text description
        string location
        int category_id FK
        string profile_image_url
        bool is_published
        bool is_active
    }
    SOCIAL_LINKS {
        int id PK
        int venture_id FK
        string platform "instagram | facebook | tiktok | whatsapp | youtube"
        string url
        bool is_active
    }
    FOLLOWER_STATS {
        int id PK
        int social_link_id FK
        int followers
        string source "api | manual"
        datetime updated_at
    }
    SOCIAL_INTEGRATIONS {
        int social_link_id PK
        string external_account_id
        string access_token_encrypted
        datetime expires_at
    }
    FAVORITES {
        int account_id PK "ref. logica a auth"
        int venture_id PK
        datetime created_at
    }
```

Las 6 tablas de `ACCOUNTS...` ya están implementadas (Fase 3). El resto pertenece al servicio `emprendimientos` (Fases 4-6). La unión con las herramientas actuales se hará con una columna `account_id` (nula) en `usuarios.users` mediante una migración SQL versionada (Fase 5; `create_all` no altera tablas existentes).

### Información pública vs. privada
El catálogo solo lee campos públicos de `ventures` con `is_published = true`; los DTO públicos no incluyen `owner_account_id` ni `social_integrations` (tokens). Qué otros datos privados guarda el emprendedor está **pendiente de definir** (ver sección 5).

## 3. Hoja de ruta por fases

| Fase | Contenido | Estado |
|---|---|---|
| 1 | Análisis | ✔ |
| 2 | Plan | ✔ (este documento) |
| **3** | **Servicio `auth`, roles, sesión segura, Google/Facebook (preparado), gateway con JWT, Compose** | ✔ **entregada** |
| **4** | **Frontend: pantalla inicial con los 2 ingresos, registro/login/recuperación, contexto de sesión; servicio `emprendimientos` (catálogo, categorías, favoritos, «Mi emprendimiento» básico); interfaz del visitante** | ✔ **entregada** |
| 5 | Panel del emprendedor (6 secciones), herramientas actuales dentro del panel, `PROTECT_LEGACY=True`, permisos por dueño, migraciones | pendiente |
| 6 | Foto de perfil del emprendimiento; integraciones oficiales de redes (según viabilidad real de cada API) | pendiente |
| 7 | Pruebas de permisos, navegación, persistencia y responsive; documentación final; manifiestos K8s de `auth` | pendiente |

## 4. Fase 3 — Qué se entregó

### Servicio `auth` (`backend/microservicios/auth/`)
| Método y ruta pública (`/api/v1/auth/...`) | Acceso | Qué hace |
|---|---|---|
| `POST /register` | público | Crea cuenta con rol inicial (`visitor`/`entrepreneur`) y abre sesión |
| `POST /login` | público | Correo + contraseña |
| `POST /refresh` | cookie | Renueva el acceso y rota la cookie |
| `POST /logout` | cookie | Revoca la sesión |
| `GET /me` | JWT | Cuenta y roles |
| `POST /roles` | JWT | Habilita el otro rol en la misma cuenta |
| `GET /me/audits` | JWT | Auditoría de la cuenta |
| `POST /password/forgot` · `POST /password/reset` | público | Recuperación (respuesta uniforme, enlace de un solo uso, 1 h) |
| `GET /oauth/providers` | público | Qué proveedores están configurados |
| `GET /oauth/{google\|facebook}/login?role=` | público | Devuelve la URL del proveedor |
| `GET /oauth/{provider}/callback` | proveedor | Cierra el flujo y fija la cookie |

### Seguridad implementada
- Contraseñas scrypt con sal; mínimo 8 y máximo 128 caracteres; mismo mensaje y tiempo para "correo inexistente" y "contraseña incorrecta".
- Bloqueo tras 5 fallos por correo en 15 min.
- Refresh tokens: solo se guarda su hash SHA-256; rotación en cada uso; **reuso de un token revocado cierra todas las sesiones**.
- Tras restablecer la contraseña se cierran todas las sesiones.
- JWT RS256 con `iss`, `aud`, `exp`, `kid`; la llave privada nunca sale del servicio.
- OAuth: `state` firmado con otra audiencia (no sirve como token de acceso), ligado a la cookie del navegador (anti-CSRF), sin enlace automático con cuentas existentes.
- Respuestas de `/auth` con `Cache-Control: no-store`.
- Ningún proveedor se simula: sin credenciales, `oauth/providers` informa `false` y el login responde 503.

### Variables de entorno (`backend/microservicios/auth/.env.example`)
`PUBLIC_URL`, `FRONTEND_URL`, `COOKIE_SECURE`, `GOOGLE_CLIENT_ID/SECRET`, `FACEBOOK_APP_ID/SECRET/API_VERSION`, `MAIL_MODE` + `SMTP_*`, `ACCESS_TOKEN_MINUTES`, `REFRESH_TOKEN_DAYS`, `RESET_TOKEN_MINUTES`, `JWT_PRIVATE_KEY` (opcional), `DATABASE_URL`.

### Credenciales externas que necesitarán
- **Google:** ID de cliente OAuth (consola de Google Cloud) con la URI de redirección `{PUBLIC_URL}/api/v1/auth/oauth/google/callback`.
- **Facebook:** app en Meta for Developers con "Inicio de sesión con Facebook" y la URI `{PUBLIC_URL}/api/v1/auth/oauth/facebook/callback`.
- **Correo:** servidor SMTP (opcional; sin él los enlaces de recuperación salen en los logs).

## 4b. Fase 4 — Qué se entregó

### Decisiones del equipo (respondían las preguntas abiertas)
- Sin datos privados extra por ahora (no hay tabla `venture_private`).
- Categorías: lista fija sembrada al arrancar (11 iniciales; se ajustan en la tabla `categories`).
- Un emprendimiento **nace oculto (borrador)** y se publica con un botón; para publicar se exige nombre y descripción.
- **Un emprendimiento por cuenta** (`owner_account_id` único).

### Servicio `emprendimientos` (puerto 8006, BD propia `emprendimientos`)
Tablas: `categories`, `ventures`, `social_links`, `follower_stats`, `favorites`, `venture_audit`. Sin llaves foráneas hacia `auth`: solo guarda el id de la cuenta.

| Acceso | Rutas (públicas, tras `/api/v1`) |
|---|---|
| Sin sesión | `GET /categories`, `GET /ventures?q=&category_id=&limit=&offset=`, `GET /ventures/{id}` (solo publicados y activos) |
| Rol `entrepreneur` | `GET/PUT/DELETE /me/venture`, `POST /me/venture/{publish,unpublish,restore}`, `GET /me/venture/audits`, `PUT/DELETE /me/venture/social/{red}` |
| Cualquier sesión | `GET /me/favorites`, `GET /me/favorite-ids`, `PUT/DELETE /me/favorites/{id}` |

- La identidad llega **solo** en `X-User-Id`, que fija el gateway a partir del JWT. El servicio no se publica fuera de la red de Compose.
- El perfil público **nunca** incluye el id de la cuenta dueña; el nombre del emprendedor solo sale si marcó «mostrar mi nombre».
- Redes del negocio: se valida el dominio de cada red (instagram.com, facebook.com/fb.com/fb.me, tiktok.com, wa.me/whatsapp.com, youtube.com/youtu.be). Los seguidores se guardan con `source`: `manual` se muestra como «declarado por el emprendedor».
- Borrado lógico del emprendimiento (`is_active`), con `/restore` (vuelve como borrador) y registro en `venture_audit`.
- Se usan rutas bajo `/me/...` para no mezclar rutas fijas y con parámetro bajo un mismo prefijo en el gateway.

### Auth: ventana de gracia del refresh (10 s)
Si dos pestañas renuevan la sesión a la vez, la segunda ya no se interpreta como robo (no cierra sesiones ni borra la cookie). Pasados 10 s, reutilizar un token viejo sigue cerrando todas las sesiones.

### Frontend (React)
Rutas nuevas: `/` (dos ingresos), `/ingresar`, `/registro`, `/recuperar`, `/restablecer`, `/explorar`, `/emprendimiento/:id`, `/favoritos`, `/cuenta`, `/panel`, `/panel/emprendimiento`. El access token vive solo en memoria; al recargar se recupera con la cookie de refresh. Una sola renovación en paralelo y un reintento de la petición. Los botones de Google/Facebook solo aparecen si el servidor los tiene configurados. Los CRUD existentes quedaron dentro del panel («Herramientas»), protegidos en la interfaz por rol.

## 5. Limitaciones conocidas y decisiones pendientes

**Limitaciones de la Fase 3**
1. Los CRUD existentes **siguen sin protección** hasta la Fase 5 (`PROTECT_LEGACY = False` en `generate.py`), porque el frontend aún no envía token. Los microservicios solo deben ser alcanzables desde el gateway (en Compose ya lo son: solo se publican 8000 y 8080).
2. El correo del registro con contraseña **no se verifica** (no estaba pedido). Por eso OAuth nunca se enlaza solo con una cuenta existente.
3. El bloqueo por intentos vive en memoria del proceso: con varias réplicas cada una cuenta aparte.
4. Las rutas del frontend `/ingresar`, `/restablecer` y `/?oauth=ok` las creó la Fase 4.
5. Se ejecutaron 57 pruebas de la lógica (contraseñas, tokens, sesiones, roles, recuperación y OAuth con proveedor simulado). **No se pudieron ejecutar** las pruebas de la capa HTTP (`tests/test_api.py`), ni FastAPI/Postgres, ni la validación del JWT en KrakenD: se verifican siguiendo `docs/reorientacion/GUIA_FASE3.md`.

**Limitaciones de la Fase 4**
1. Los CRUD existentes (usuarios, metodologías, beneficios, análisis) **siguen sin protección en el gateway** hasta la Fase 5; la interfaz ya los oculta a quien no es emprendedor, pero eso no es seguridad.
2. Sin foto de perfil del emprendimiento (Fase 6): la tarjeta muestra la inicial del nombre.
3. Los seguidores son siempre **declarados**; la verificación por API es de la Fase 6.
4. «Compartir» usa el menú del dispositivo o copia el enlace; las páginas no tienen vista previa para redes (requeriría generación en servidor).
5. Las pruebas HTTP del servicio nuevo y la validación del gateway se ejecutan en su entorno (ver `GUIA_FASE4.md`); aquí se probaron la lógica (24 pruebas) y la interfaz completa contra un servidor simulado.

**Pendiente**
1. Viabilidad de seguidores automáticos por plataforma: se **verifica en la Fase 6** contra la documentación vigente de cada API (algunas exigen cuenta profesional, revisión de la app o no ofrecen la cifra; WhatsApp no tiene seguidores). Donde no se pueda, queda el ingreso manual, marcado como tal.
